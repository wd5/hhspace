django-validforms
=================

This django app brings you client side validation for your forms. Define the validators in your django form using our classes, and enjoy automatic javascript-powered form interaction for the user
